package org.example.orda.repository;

import org.example.orda.model.ApplicationRequest;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

@Repository
public interface RepositoryAR extends JpaRepository<ApplicationRequest, Long> {
}
