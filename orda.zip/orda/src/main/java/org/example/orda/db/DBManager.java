package org.example.orda.db;


import org.example.orda.model.ApplicationRequest;
import org.example.orda.repository.RepositoryAR;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class DBManager {
    @Autowired
    private final RepositoryAR repositoryAR;
    public DBManager(RepositoryAR repositoryAR) {
        this.repositoryAR = repositoryAR;
    }

    public List<ApplicationRequest> getAllApplicationRequest(){
        List<ApplicationRequest> all = repositoryAR.findAll();
        return all;
    }

    public  void addApplicationRequest(ApplicationRequest student){
        repositoryAR.save(student);

    }

    public ApplicationRequest getApplicationRequestById(Long id) {
        ApplicationRequest app = repositoryAR.getById(id);
        return app;

    }

//    public static void updateStudent(Long id, ApplicationRequest student){
//        for (ApplicationRequest stud : studentList) {
//            if (stud.getId().equals(id)){
//                studentList.set(Integer.parseInt(String.valueOf(id)), student);
//            }
//        }
//    }

//    public static void deleteStudent(Long id){
//        for (ApplicationRequest stud : studentList) {
//            if (stud.getId().equals(id)){
//                studentList.remove(Integer.parseInt(String.valueOf(id)));
//            }
//        }
//    }
}
